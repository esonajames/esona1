function start_by_word(str)
 {
 str = "Javascript";
  if(str.length < 4)
  {
    return false;

}
front = str.substring(0, 4);
if(front == 'Java')
 {
    return true;
}
else 
{
    return false;
}
 }
console.log(start_by_word("Javascript"));

