var hr = 100;
var hour = hr / 60;
var minutes = hour % 60;
console.log(Math.floor(hour) + "hours" + minutes + "minutes");
