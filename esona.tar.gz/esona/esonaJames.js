var number1 = 500;
var number2 = 15;
var number3 = 1000;

if (number1>number2&&number1>number3) {
    console.log(number1);
}
else if(number2>number1&&number2>number3) {
console.log(number2);
}
else if(number3>number1&&number3>number2) {
    console.log(number3);
}
                                                                                                                                                                                                                                                                                                              