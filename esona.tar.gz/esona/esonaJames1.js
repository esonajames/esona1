var today = new Date();
var day = today.getDay();
var daylist = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
console.log("Today is : " + daylist[day] + ".");
var hour = today.getHours();
var minute = today.getMinutes();
var second = today.getSeconds();
var clock = (hour >=12)? " PM ":" AM ";
hour = (hour >= 12)? hour - 12: hour;
if(hour===0 && clock=== 'PM')
{
    if(minute===0 && second===0)
    {
        hour = 12;
        clock = 'Noon';
    }
    else{
        hour = 12;
        clock = 'PM';
    }
    }
if(hour===0 && clock==='AM')
{
    if(minute===0 && second===0)
    {
        hour = 12;
        clock = 'Midnight'; 
    }
    else{
        hour = 12;
        clock = 'AM';
    }
}
console.log("<br/>");
console.log("current Time : " +hour + clock + ":" + minute + ":" + second);

 