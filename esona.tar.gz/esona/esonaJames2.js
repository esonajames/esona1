//Javasript program to get website URL (loading page)
console.log(document.URL);